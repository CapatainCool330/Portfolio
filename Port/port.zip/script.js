var typed = new Typed(".text", {
  strings: ["Front-end Developer", "Programmer", "Web Developer"],
  typeSpeed: 75,
  backSpeed: 75,
  backDelay: 1000,
  loop: true
});

document.querySelector(".bxl-instagram").addEventListener("click", ()=>{
  
})